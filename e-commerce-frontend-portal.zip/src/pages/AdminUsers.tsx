import React, { useState, useEffect } from "react";
import api from "../api/axios";
import { useApp } from "../context/AppContext";
import { User } from "../types";
import { Users2, Shield, Mail, Calendar, RefreshCw, Trash2, Ban } from "lucide-react";

export default function AdminUsers() {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState(true);
  const { showToaster } = useApp();

  const loadUsers = async () => {
    setLoading(true);
    try {
      const res = await api.get("/auth/users");
      if (Array.isArray(res.data)) {
        setUsers(res.data);
      } else {
        setUsers([]);
      }
    } catch (err) {
      console.error(err);
      showToaster("Error loading customer registry list. Displaying active session credentials only context.", "info");
      
      // Fallback mockup
      setUsers([
        { id: "1", name: "Executive Manager", email: "admin@example.com", role: "ADMIN" },
        { id: "2", name: "Premium Customer", email: "user@example.com", role: "USER" },
      ]);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-8 text-slate-900">
      <div className="flex justify-between items-center pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Users2 className="text-teal-600" size={24} />
            Registered Users Directory
          </h1>
          <p className="text-xs text-slate-500 mt-1">Audit active security credentials, profiles, and administration privileges.</p>
        </div>
        <button
          onClick={loadUsers}
          className="p-2 border border-slate-200 hover:bg-slate-50 rounded-xl bg-white text-slate-600 cursor-pointer shadow-xs"
        >
          <RefreshCw size={14} />
        </button>
      </div>

      {loading ? (
        <div className="max-w-7xl mx-auto py-16 flex flex-col items-center justify-center min-h-[30vh]">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-900"></div>
          <p className="text-slate-450 text-xs mt-4">Auditing active registries...</p>
        </div>
      ) : (
        <div className="bg-white rounded-3xl border border-slate-200 overflow-hidden shadow-xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-50 border-b border-slate-200 text-slate-400 font-mono text-[10px] font-bold uppercase tracking-widest">
                  <th className="py-4 px-6">Profile Identifier</th>
                  <th className="py-4 px-6">Display Name</th>
                  <th className="py-4 px-6">Email Address</th>
                  <th className="py-4 px-6">Security Permissions</th>
                  <th className="py-4 px-6 text-center">Status Flags</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-xs">
                {users.map((u) => (
                  <tr key={u.id} className="hover:bg-slate-50/50 transition-colors">
                    <td className="py-4 px-6 font-mono font-bold text-slate-500">
                      #{u.id}
                    </td>
                    <td className="py-4 px-6 font-semibold text-slate-800">
                      {u.name}
                    </td>
                    <td className="py-4 px-6 font-mono font-semibold text-slate-600">
                      {u.email}
                    </td>
                    <td className="py-4 px-6">
                      <span
                        className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-[10px] font-mono font-bold tracking-wider uppercase border ${
                          u.role === "ADMIN"
                            ? "bg-rose-50 border-rose-200 text-rose-700 font-bold"
                            : "bg-teal-50 border-teal-200 text-teal-700"
                        }`}
                      >
                        <Shield size={10} />
                        {u.role}
                      </span>
                    </td>
                    <td className="py-4 px-6 text-center">
                      <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 text-[10px] font-mono font-bold px-2 py-0.5 rounded-md uppercase border border-emerald-200">
                        ACTIVE STATE
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
