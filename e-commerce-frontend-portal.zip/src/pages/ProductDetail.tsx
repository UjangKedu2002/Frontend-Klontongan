import React, { useState, useEffect } from "react";
import { useParams, Link, useNavigate } from "react-router-dom";
import api from "../api/axios";
import { useApp } from "../context/AppContext";
import { Product } from "../types";
import { ShoppingBag, ChevronLeft, Plus, Minus, Tag, ShieldAlert, Award } from "lucide-react";

export default function ProductDetail() {
  const { id } = useParams();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [qty, setQty] = useState(1);
  const { addToCart, showToaster } = useApp();
  const navigate = useNavigate();

  const loadProduct = async () => {
    setLoading(true);
    try {
      const res = await api.get(`/products/${id}`);
      if (res.data) {
        setProduct(res.data);
      } else {
        showToaster("Product details not found inside database", "error");
      }
    } catch (err) {
      console.error(err);
      showToaster("Error retrieving detailed product specifications", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (id) {
      loadProduct();
    }
  }, [id]);

  const handleDecrease = () => {
    if (qty > 1) setQty(qty - 1);
  };

  const handleIncrease = () => {
    if (product && qty < product.stock) {
      setQty(qty + 1);
    } else {
      showToaster("You cannot exceed registered stock counts!", "info");
    }
  };

  const handleAddToCart = async () => {
    if (!product) return;
    const success = await addToCart(product.id, qty);
    if (success) {
      navigate("/cart");
    }
  };

  const formatIDR = (num: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      maximumFractionDigits: 0,
    }).format(num);
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-16 flex flex-col items-center justify-center min-h-[50vh] relative z-10">
        <div className="animate-spin rounded-full h-10 w-10 border-2 border-indigo-500 border-t-transparent shadow-[0_0_20px_rgba(99,102,241,0.2)]"></div>
        <p className="text-slate-400 text-xs mt-4 font-mono">Consulting active database catalog tables...</p>
      </div>
    );
  }

  if (!product) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-16 text-center relative z-10">
        <h3 className="text-xl font-bold font-display text-white">Resource Offline</h3>
        <p className="text-slate-400 text-xs mt-1 mb-6">The requested product could not be located in your database tables.</p>
        <Link to="/" className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-550 text-white rounded-xl text-xs font-bold">
          Return to Catalog
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-10 relative z-10">
      <Link to="/" className="inline-flex items-center gap-1.5 text-xs text-indigo-400 hover:text-indigo-300 mb-8 font-bold transition-colors">
        <ChevronLeft size={14} />
        Back to Dynamic Inventory List
      </Link>

      <div className="glass-panel rounded-3xl overflow-hidden shadow-[0_0_50px_rgba(79,70,229,0.15)] grid grid-cols-1 md:grid-cols-2 gap-8 p-6 sm:p-8 border border-white/10">
        {/* Left column: image aspect */}
        <div className="rounded-2xl bg-white/5 aspect-square overflow-hidden relative border border-white/10 flex items-center justify-center shadow-lg">
          {product.image ? (
            <img
              src={product.image}
              alt={product.name}
              className="w-full h-full object-cover"
              referrerPolicy="no-referrer"
            />
          ) : (
            <div className="text-slate-500 font-mono text-xs flex flex-col items-center">
              <ShoppingBag size={48} className="mb-3 opacity-30 text-indigo-400" />
              Inventory photo unregistered
            </div>
          )}
          <span className="absolute top-4 left-4 inline-flex items-center gap-1.5 bg-slate-950/80 text-indigo-300 border border-white/10 text-[10px] font-mono font-bold uppercase tracking-widest px-3 py-1.5 rounded-lg shadow-lg backdrop-blur-md">
            <Tag size={12} className="text-indigo-400" />
            {product.category || "General"}
          </span>
        </div>

        {/* Right column: purchase panel */}
        <div className="flex flex-col justify-between space-y-6">
          <div className="space-y-4">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded text-[9px] font-mono font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 uppercase tracking-widest">
              Available in Database
            </span>
            <h1 className="text-2xl sm:text-3xl font-display font-bold tracking-tight text-white leading-tight">
              {product.name}
            </h1>
            <p className="text-3xl font-bold text-white font-sans tracking-tight">
              {formatIDR(product.price)}
            </p>
            <div className="bg-white/5 rounded-xl p-4 border border-white/10 text-xs text-slate-350 leading-relaxed">
              <h4 className="font-bold text-indigo-300 text-xs uppercase font-mono tracking-wider mb-2">Item Specifications</h4>
              <p>{product.description || "The administrator has registered this catalog resource without supplemental information schemas."}</p>
            </div>
          </div>

          <div className="space-y-4 pt-4 border-t border-white/10">
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-widest font-mono block">Quantity</span>
                <span className="text-[11px] font-mono text-slate-500">{product.stock} pieces available</span>
              </div>
              <div className="flex items-center border border-white/15 rounded-lg overflow-hidden bg-white/5 shrink-0">
                <button
                  type="button"
                  onClick={handleDecrease}
                  disabled={qty <= 1}
                  className="px-3 py-2 text-slate-400 hover:bg-white/10 hover:text-white transition-colors disabled:opacity-30"
                >
                  <Minus size={14} />
                </button>
                <span className="px-4 text-xs font-bold text-white font-mono select-none w-10 text-center">
                  {qty}
                </span>
                <button
                  type="button"
                  onClick={handleIncrease}
                  disabled={qty >= product.stock}
                  className="px-3 py-2 text-slate-400 hover:bg-white/10 hover:text-white transition-colors disabled:opacity-30"
                >
                  <Plus size={14} />
                </button>
              </div>
            </div>

            {/* Direct Add Action Button */}
            <button
              onClick={handleAddToCart}
              disabled={product.stock <= 0}
              className="w-full flex items-center justify-center gap-2 py-3.5 px-4 bg-indigo-650 border border-transparent rounded-xl text-white font-bold text-sm hover:bg-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-505 transition-all disabled:opacity-50 disabled:bg-white/5 disabled:text-slate-500 cursor-pointer disabled:cursor-not-allowed shadow-[0_0_20px_rgba(79,70,229,0.35)]"
            >
              <ShoppingBag size={16} />
              {product.stock > 0 ? "Commit and Push to Database Cart" : "Item Sold Out"}
            </button>
          </div>

          {/* Customer assurance notices */}
          <div className="grid grid-cols-2 gap-4 pt-4 border-t border-white/10 text-[11px] text-slate-500">
            <div className="flex items-center gap-1.5 font-mono">
              <Award size={14} className="text-indigo-400" />
              <span>Postgres Authenticated</span>
            </div>
            <div className="flex items-center gap-1.5 font-mono">
              <ShieldAlert size={14} className="text-indigo-400" />
              <span>Full Stack connected</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
