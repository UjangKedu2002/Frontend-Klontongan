import React, { useState, useEffect } from "react";
import api from "../api/axios";
import { useApp } from "../context/AppContext";
import { Product } from "../types";
import { Plus, Edit2, Trash2, Camera, RefreshCw, XCircle, Ban, Hammer, EyeOff, Save, Sparkles, AlertCircle } from "lucide-react";

export default function AdminProducts() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Form State
  const [editingId, setEditingId] = useState<string | number | null>(null);
  const [name, setName] = useState("");
  const [description, setDescription] = useState("");
  const [price, setPrice] = useState<number>(0);
  const [stock, setStock] = useState<number>(0);
  const [category, setCategory] = useState("");
  const [image, setImage] = useState(""); // Holds imageUrl return from backend
  const [isUploading, setIsUploading] = useState(false);
  const [submitLoading, setSubmitLoading] = useState(false);
  const { showToaster } = useApp();

  const loadProducts = async () => {
    setLoading(true);
    try {
      const res = await api.get("/products");
      if (Array.isArray(res.data)) {
        setProducts(res.data);
      } else {
        setProducts([]);
      }
    } catch (err) {
      console.error(err);
      showToaster("Error loading product catalog lists", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProducts();
  }, []);

  // Handle single file image uploading
  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Build standard multipart request
    const formData = new FormData();
    // Field name MUST BE "image" as specified in instructions
    formData.append("image", file);

    setIsUploading(true);
    try {
      showToaster("Uploading image resource to Cloud Node...", "info");
      const res = await api.post("/upload", formData, {
        headers: { "Content-Type": "multipart/form-data" },
      });
      // Response returns under data.imageUrl
      if (res.data?.imageUrl) {
        setImage(res.data.imageUrl);
        showToaster("Image uploaded and cached successfully!", "success");
      } else {
        showToaster("Server accepted image but didn't return url", "error");
      }
    } catch (err: any) {
      console.error(err);
      showToaster(err.response?.data?.message || "Failed to commit image asset to remote servers", "error");
    } finally {
      setIsUploading(false);
    }
  };

  const handleEditSetup = (product: Product) => {
    setEditingId(product.id);
    setName(product.name);
    setDescription(product.description || "");
    setPrice(product.price);
    setStock(product.stock);
    setCategory(product.category || "");
    setImage(product.image || "");
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleResetForm = () => {
    setEditingId(null);
    setName("");
    setDescription("");
    setPrice(0);
    setStock(0);
    setCategory("");
    setImage("");
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || price <= 0 || stock < 0 || !category) {
      showToaster("Please fill in all core parameters appropriately.", "error");
      return;
    }

    setSubmitLoading(true);
    const payload = { name, description, price, stock, category, image };

    try {
      if (editingId) {
        // PUT /products/:id
        await api.put(`/products/${editingId}`, payload);
        showToaster(`SKU ID ${editingId} modified in cloud tables successfully!`, "success");
      } else {
        // POST /products
        await api.post("/products", payload);
        showToaster("New product record created in PostgreSQL list!", "success");
      }
      handleResetForm();
      await loadProducts();
    } catch (err: any) {
      console.error(err);
      showToaster(err.response?.data?.message || "Error submitting product modifications to server", "error");
    } finally {
      setSubmitLoading(false);
    }
  };

  const handleDelete = async (id: string | number) => {
    if (!window.confirm("Are you absolutely sure you wish to delete this SKU catalog listing?")) return;
    try {
      await api.delete(`/products/${id}`);
      showToaster("SKU product row purged on remote postgres databases!", "success");
      await loadProducts();
    } catch (err: any) {
      console.error(err);
      showToaster(err.response?.data?.message || "Remote delete query refused.", "error");
    }
  };

  const formatIDR = (num: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      maximumFractionDigits: 0,
    }).format(num);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 py-8 space-y-10 text-slate-900">
      {/* Header section */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <Hammer className="text-teal-600" size={24} />
          SKU Inventory Administrator
        </h1>
        <p className="text-xs text-slate-500 mt-1">Direct listing creations, catalog edits, and media image mapping interfaces.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 items-start">
        {/* Left Side Column: Form for adding and updating products */}
        <div className="lg:col-span-1 bg-white p-6 rounded-3xl border border-slate-200 shadow-xs h-fit space-y-6">
          <div className="pb-4 border-b border-slate-100 flex items-center justify-between">
            <h3 className="text-sm font-bold uppercase font-mono tracking-wider flex items-center gap-2">
              <Sparkles size={16} className="text-teal-600" />
              {editingId ? "Modify Resource SKU" : "Register Product Listing"}
            </h3>
            {editingId && (
              <button
                onClick={handleResetForm}
                className="text-[10px] bg-slate-105 hover:bg-slate-150 px-2 py-1 rounded font-bold font-mono text-slate-500 uppercase cursor-pointer"
              >
                CANCEL EDIT
              </button>
            )}
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            {/* Display Title input */}
            <div className="space-y-1.5 prose">
              <label className="block text-xs font-semibold text-slate-700 uppercase tracking-widest font-mono">Product Name</label>
              <input
                type="text"
                required
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="IndoMart Super Product"
                className="w-full px-3 py-2 bg-slate-50 border border-slate-205 rounded-lg text-xs font-medium placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-teal-500"
              />
            </div>

            {/* Category selection */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-705 uppercase tracking-widest font-mono">Product Category</label>
              <input
                type="text"
                required
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                placeholder="Electronics, Fashion, Food, etc..."
                className="w-full px-3 py-2 bg-slate-50 border border-slate-205 rounded-lg text-xs font-medium placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-teal-500"
              />
            </div>

            {/* Pricing details */}
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-705 uppercase tracking-widest font-mono">Price (IDR)</label>
                <input
                  type="number"
                  required
                  min="0"
                  value={price || ""}
                  onChange={(e) => setPrice(Number(e.target.value))}
                  placeholder="350000"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-205 rounded-lg text-xs font-mono font-bold placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-teal-500"
                />
              </div>

              <div className="space-y-1.5">
                <label className="block text-xs font-semibold text-slate-705 uppercase tracking-widest font-mono">Units Stock</label>
                <input
                  type="number"
                  required
                  min="0"
                  value={stock === 0 && stock !== 0 ? "" : stock}
                  onChange={(e) => setStock(Number(e.target.value))}
                  placeholder="15"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-205 rounded-lg text-xs font-mono font-bold placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-teal-500"
                />
              </div>
            </div>

            {/* Detailed description */}
            <div className="space-y-1.5">
              <label className="block text-xs font-semibold text-slate-705 uppercase tracking-widest font-mono">Specification Details</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Detail materials, sizing, features, or shipping bounds..."
                rows={3}
                className="w-full px-3 py-2 bg-slate-50 border border-slate-205 rounded-lg text-xs font-medium placeholder-slate-400 focus:outline-none focus:ring-1 focus:ring-teal-500"
              />
            </div>

            {/* Image Upload Block with Image File Input and Response Preview */}
            <div className="space-y-2">
              <label className="block text-xs font-semibold text-slate-705 uppercase tracking-widest font-mono mb-1">Product Media Asset</label>
              
              <div className="border border-dashed border-slate-200 bg-slate-50 hover:bg-slate-100 rounded-xl p-4 text-center cursor-pointer relative transition-all">
                <input
                  type="file"
                  accept="image/*"
                  onChange={handleImageUpload}
                  disabled={isUploading}
                  className="absolute inset-0 opacity-0 cursor-pointer w-full h-full disabled:cursor-not-allowed"
                />
                <div className="flex flex-col items-center justify-center space-y-2">
                  <div className="p-2.5 bg-white text-slate-500 rounded-full border border-slate-100 shadow-xs">
                    <Camera size={16} />
                  </div>
                  <span className="text-xs font-semibold text-slate-700 block">Click to Upload Image</span>
                  <span className="text-[10px] text-slate-400 font-mono">Field image. Accepts common formats.</span>
                </div>
              </div>

              {/* Show URL preview state if URL exists */}
              {image && (
                <div className="pt-2">
                  <span className="text-[10px] font-mono text-slate-400 block mb-1">UPLOADED RESULT PREVIEW:</span>
                  <div className="rounded-xl border border-slate-200 overflow-hidden bg-slate-105 h-32 relative flex items-center justify-center">
                    <img
                      src={image}
                      alt="Upload Preview"
                      className="w-full h-full object-cover"
                      referrerPolicy="no-referrer"
                    />
                    <button
                      type="button"
                      onClick={() => setImage("")}
                      className="absolute top-2 right-2 bg-white/90 hover:bg-white text-rose-600 rounded-lg p-1 transition-colors border border-slate-200"
                      title="Clear caching"
                    >
                      <XCircle size={14} />
                    </button>
                  </div>
                </div>
              )}
            </div>

            <button
              type="submit"
              disabled={submitLoading || isUploading}
              className="w-full flex items-center justify-center gap-1.5 py-3 bg-slate-900 border border-transparent rounded-xl text-white font-semibold text-xs hover:bg-slate-800 transition-colors cursor-pointer disabled:opacity-75 disabled:cursor-not-allowed"
            >
              <Save size={14} />
              {submitLoading ? "Uploading Data Schema..." : editingId ? "Confirm PostgreSQL Upgrades" : "Publish to Catalog Table"}
            </button>
          </form>
        </div>

        {/* Right Side Column: Product Inventory Grid List */}
        <div className="lg:col-span-2 space-y-4">
          <div className="flex justify-between items-center pb-3 border-b border-slate-200">
            <span className="text-xs font-mono font-bold text-slate-400 uppercase tracking-widest">
              Available catalog SKUs total: {products.length}
            </span>
            <button
              onClick={loadProducts}
              className="p-1.5 border border-slate-150 rounded-lg bg-white text-slate-600 hover:bg-slate-50 cursor-pointer shadow-xs"
              title="Refresh inventories"
            >
              <RefreshCw size={14} />
            </button>
          </div>

          {loading ? (
            <div className="py-20 text-center bg-white border border-slate-200 rounded-3xl flex flex-col items-center justify-center">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-900"></div>
              <p className="text-xs text-slate-450 mt-4">Consulting physical catalog database...</p>
            </div>
          ) : products.length === 0 ? (
            <div className="py-20 text-center bg-white border border-slate-200 rounded-3xl flex flex-col items-center justify-center px-6">
              <EyeOff size={32} className="text-slate-350 mb-3" />
              <h4 className="font-semibold text-sm text-slate-800">Your Catalogue table is empty</h4>
              <p className="text-slate-500 text-xs mt-1 max-w-sm">No items are published on Postgres Neon yet. Use the register product tool on the left to map your first SKU.</p>
            </div>
          ) : (
            <div className="space-y-3">
              {products.map((p) => (
                <div
                  key={p.id}
                  className="bg-white rounded-2xl border border-slate-200 p-4 shadow-xs flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between hover:border-slate-300 transition-colors"
                >
                  <div className="flex gap-4 items-center min-w-0">
                    <div className="w-12 h-12 rounded-lg bg-slate-100 border border-slate-150 overflow-hidden shrink-0">
                      {p.image ? (
                        <img src={p.image} alt="SKU icon" className="w-full h-full object-cover" referrerPolicy="no-referrer" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center text-slate-400">
                          <Plus size={16} />
                        </div>
                      )}
                    </div>

                    <div className="min-w-0">
                      <h4 className="font-bold text-slate-900 text-sm truncate">{p.name}</h4>
                      <div className="flex flex-wrap items-center gap-2 mt-1 text-[10px] font-mono font-bold uppercase shrink-0">
                        <span className="bg-slate-100 text-slate-600 px-1.5 py-0.5 rounded">
                          {p.category || "General"}
                        </span>
                        <span className="text-slate-400">|</span>
                        <span className={`${p.stock > 0 ? "text-teal-600" : "text-rose-600"}`}>
                          Units: {p.stock}
                        </span>
                        <span className="text-slate-405">|</span>
                        <span className="text-slate-800">{formatIDR(p.price)}</span>
                      </div>
                    </div>
                  </div>

                  {/* Operational actions */}
                  <div className="flex gap-2 self-end sm:self-center shrink-0">
                    <button
                      onClick={() => handleEditSetup(p)}
                      className="p-2 border border-slate-200 hover:bg-slate-50 text-slate-600 hover:text-slate-900 rounded-lg shadow-xs cursor-pointer transition-colors"
                      title="Edit product info"
                    >
                      <Edit2 size={12} />
                    </button>
                    <button
                      onClick={() => handleDelete(p.id)}
                      className="p-2 border border-slate-200 hover:bg-rose-50 text-rose-600 rounded-lg shadow-xs cursor-pointer transition-colors"
                      title="Purge product record"
                    >
                      <Trash2 size={12} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
