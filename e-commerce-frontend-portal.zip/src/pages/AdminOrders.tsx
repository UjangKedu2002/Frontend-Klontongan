import React, { useState, useEffect } from "react";
import api from "../api/axios";
import { useApp } from "../context/AppContext";
import { Order } from "../types";
import { Truck, Calendar, Receipt, ChevronDown, ChevronUp, RefreshCw, EyeOff, CheckSquare, Clock } from "lucide-react";

export default function AdminOrders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedOrders, setExpandedOrders] = useState<Record<string | number, boolean>>({});
  const [updatingId, setUpdatingId] = useState<string | number | null>(null);
  const { showToaster } = useApp();

  const loadOrders = async () => {
    setLoading(true);
    try {
      const res = await api.get("/orders");
      if (Array.isArray(res.data)) {
        setOrders(res.data);
      } else {
        setOrders([]);
      }
    } catch (err) {
      console.error(err);
      showToaster("Error retrieving full system order lists", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadOrders();
  }, []);

  const toggleExpand = async (order: Order) => {
    const oId = order.id;
    const isNowExpanded = !expandedOrders[oId];
    setExpandedOrders((prev) => ({ ...prev, [oId]: isNowExpanded }));

    // Auto-fetch relation sub-items details inline
    if (isNowExpanded && !order.items) {
      try {
        const res = await api.get(`/orders/${oId}`);
        setOrders((prev) =>
          prev.map((o) => (o.id === oId ? { ...o, ...res.data } : o))
        );
      } catch (err) {
        console.error("Failed to query order details sheet:", err);
      }
    }
  };

  const updateStatus = async (orderId: string | number, nextStatus: "SHIPPED" | "COMPLETED") => {
    setUpdatingId(orderId);
    try {
      await api.patch(`/orders/${orderId}/status`, { status: nextStatus });
      showToaster(`Order status upgraded to: ${nextStatus}!`, "success");
      
      // Upgrade state locally
      setOrders((prev) =>
        prev.map((o) => (o.id === orderId ? { ...o, status: nextStatus } : o))
      );
    } catch (err: any) {
      console.error(err);
      showToaster(err.response?.data?.message || `Failed to transition status to: ${nextStatus}`, "error");
    } finally {
      setUpdatingId(null);
    }
  };

  const formatIDR = (num: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      maximumFractionDigits: 0,
    }).format(num);
  };

  const getStatusBadge = (status: string) => {
    const s = status?.toUpperCase();
    switch (s) {
      case "COMPLETED":
      case "PAID":
        return (
          <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 border border-emerald-200 text-[10px] font-mono font-bold tracking-wider px-2 py-0.5 rounded-md uppercase">
            {s}
          </span>
        );
      case "PENDING":
        return (
          <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-700 border border-amber-250 text-[10px] font-mono font-bold tracking-wider px-2 py-0.5 rounded-md uppercase animate-pulse">
            PENDING
          </span>
        );
      case "SHIPPED":
        return (
          <span className="inline-flex items-center gap-1 bg-blue-50 text-blue-700 border border-blue-200 text-[10px] font-mono font-bold tracking-wider px-2 py-0.5 rounded-md uppercase">
            SHIPPED
          </span>
        );
      case "CANCELLED":
      case "EXPIRED":
        return (
          <span className="inline-flex items-center gap-1 bg-slate-100 text-slate-500 border border-slate-200 text-[10px] font-mono font-bold tracking-wider px-2 py-0.5 rounded-md uppercase">
            {s}
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 bg-slate-50 text-slate-600 border border-slate-200 text-[10px] font-mono font-bold tracking-wider px-2 py-0.5 rounded-md uppercase">
            {status || "UNKNOWN"}
          </span>
        );
    }
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 py-16 flex flex-col items-center justify-center min-h-[50vh]">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-slate-900"></div>
        <p className="text-slate-450 text-xs mt-4">Importing customer receipt logs...</p>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 space-y-8 text-slate-900">
      <div className="flex justify-between items-center pb-4 border-b border-slate-200">
        <div>
          <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
            <Truck className="text-teal-600" size={24} />
            Customer Orders Database
          </h1>
          <p className="text-xs text-slate-500 mt-1">Status upgrades tracking: map SHIPPED and COMPLETED sequences.</p>
        </div>
        <button
          onClick={loadOrders}
          className="p-2 border border-slate-200 hover:bg-slate-50 rounded-xl bg-white text-slate-600 cursor-pointer shadow-xs"
        >
          <RefreshCw size={14} />
        </button>
      </div>

      {orders.length === 0 ? (
        <div className="bg-white rounded-3xl border border-slate-200 py-16 text-center px-6 flex flex-col items-center justify-center">
          <EyeOff size={32} className="text-slate-350 mb-3" />
          <h4 className="font-semibold text-slate-800 text-sm">No Purchases Incurred Yet</h4>
          <p className="text-slate-500 text-xs mt-1">No orders have been pushed to PostgreSQL transactional database tables yet.</p>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map((order) => {
            const isExpanded = expandedOrders[order.id];
            const isUpdating = updatingId === order.id;

            return (
              <div
                key={order.id}
                className="bg-white rounded-2xl border border-slate-205 overflow-hidden shadow-xs hover:border-slate-300 transition-colors"
              >
                {/* Header row details */}
                <div
                  onClick={() => toggleExpand(order)}
                  className="p-5 flex flex-wrap gap-4 items-center justify-between cursor-pointer select-none bg-slate-50/40"
                >
                  <div className="space-y-1.5 min-w-[220px]">
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm font-bold text-slate-900">
                        {order.orderCode}
                      </span>
                      {getStatusBadge(order.status)}
                    </div>
                    <div className="text-[10px] font-mono text-slate-450 flex items-center gap-1">
                      <Calendar size={12} className="text-slate-450" />
                      Mapped: {new Date(order.createdAt).toLocaleString()}
                    </div>
                  </div>

                  <div className="flex items-center gap-6">
                    <div className="text-right">
                      <p className="text-[10px] font-mono font-bold uppercase tracking-widest text-slate-400">Total Charged</p>
                      <p className="text-sm font-bold font-sans tracking-tight text-slate-900">
                        {formatIDR(order.totalAmount)}
                      </p>
                    </div>
                    <div>{isExpanded ? <ChevronUp size={16} /> : <ChevronDown size={16} />}</div>
                  </div>
                </div>

                {/*展开 sub-items and status modification button grids */}
                {isExpanded && (
                  <div className="p-5 sm:p-6 border-t border-slate-200 bg-white space-y-5 animate-fade-in">
                    <div>
                      <h4 className="text-xs font-bold uppercase tracking-wider font-mono text-slate-400 mb-3">Invoice Contents</h4>
                      
                      {!order.items ? (
                        <p className="text-xs text-slate-400 font-mono">Quering matching relation cards...</p>
                      ) : (
                        <div className="divide-y divide-slate-100">
                          {order.items.map((sub) => (
                            <div key={sub.id} className="py-2.5 flex items-center justify-between text-xs">
                              <div className="min-w-0">
                                <p className="font-semibold text-slate-800 truncate">{sub.product?.name || "Product key offline"}</p>
                                <p className="text-[10px] font-mono text-slate-400">
                                  {sub.quantity} unit{sub.quantity > 1 ? "s" : ""} @ {formatIDR(sub.price)}
                                </p>
                              </div>
                              <span className="font-bold text-slate-905 font-mono">{formatIDR(sub.price * sub.quantity)}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Customer identity profiling metadata */}
                    <div className="bg-slate-50 rounded-xl p-4 border border-slate-150 text-xs text-slate-600 grid grid-cols-1 sm:grid-cols-2 gap-4">
                      <div>
                        <span className="block text-[10px] uppercase font-mono tracking-wider font-bold text-slate-400">Buyer Identity</span>
                        <span className="font-semibold text-slate-800">{order.user?.name || "Anonymous Customer"}</span>
                      </div>
                      <div>
                        <span className="block text-[10px] uppercase font-mono tracking-wider font-bold text-slate-400">Contact Address</span>
                        <span className="font-mono text-slate-800">{order.user?.email || "No email mapped"}</span>
                      </div>
                    </div>

                    {/* System controls */}
                    <div className="pt-4 border-t border-slate-100 flex flex-wrap items-center justify-between gap-4 text-xs">
                      <span className="font-semibold text-slate-400 font-mono uppercase text-[10px]">OPERATIONAL STATUS CONTROLS</span>
                      
                      <div className="flex gap-2.5">
                        {/* Shipped option */}
                        <button
                          disabled={isUpdating || order.status === "SHIPPED" || order.status === "COMPLETED"}
                          onClick={() => updateStatus(order.id, "SHIPPED")}
                          className="px-4 py-2 bg-slate-900 text-white font-semibold rounded-lg hover:bg-slate-800 disabled:bg-slate-100 disabled:text-slate-405 transition-colors cursor-pointer"
                        >
                          Mark as SHIPPED
                        </button>

                        {/* Completed option */}
                        <button
                          disabled={isUpdating || order.status === "COMPLETED"}
                          onClick={() => updateStatus(order.id, "COMPLETED")}
                          className="px-4 py-2 bg-teal-600 text-white font-semibold rounded-lg hover:bg-teal-700 disabled:bg-slate-100 disabled:text-slate-405 transition-colors cursor-pointer"
                        >
                          Mark as COMPLETED
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
