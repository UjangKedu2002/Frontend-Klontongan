import React, { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import api from "../api/axios";
import { useApp } from "../context/AppContext";
import { Trash2, ShoppingBag, Plus, Minus, CreditCard, ArrowRight, CornerDownRight, ShieldCheck, Heart } from "lucide-react";

export default function Cart() {
  const { cart, updateCartQty, removeCartItem, clearCart, showToaster, token } = useApp();
  const [loadingCheckout, setLoadingCheckout] = useState(false);
  const [paymentResult, setPaymentResult] = useState<{ orderCode: string; paymentUrl: string; snapToken: string } | null>(null);
  const navigate = useNavigate();

  const totalAmount = cart.reduce((total, item) => {
    const price = item.product?.price || 0;
    return total + price * item.quantity;
  }, 0);

  const formatIDR = (num: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      maximumFractionDigits: 0,
    }).format(num);
  };

  const handleCheckout = async () => {
    if (!token) {
      showToaster("Please login to initiate postgres database checkout", "error");
      return;
    }
    if (cart.length === 0) {
      showToaster("Your database cart represents empty bounds", "info");
      return;
    }

    setLoadingCheckout(true);
    try {
      // POST to /checkout will trigger postgres prisma schema saves and return Midtrans info
      const res = await api.post("/checkout");
      const { orderCode, paymentUrl, snapToken } = res.data;

      showToaster(`Order ${orderCode} persisted to server tables successfully!`, "success");
      setPaymentResult({ orderCode, paymentUrl, snapToken });
      
      // Clear local context cart as database items are converted into active orders
      await clearCart();
    } catch (err: any) {
      console.error(err);
      showToaster(err.response?.data?.message || "Postgres Neon schema checkout rejection.", "error");
    } finally {
      setLoadingCheckout(false);
    }
  };

  if (cart.length === 0 && !paymentResult) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center relative z-10">
        <div className="p-5 bg-white/5 border border-white/10 inline-block rounded-full mb-4 text-slate-400">
          <ShoppingBag size={48} className="text-indigo-400" />
        </div>
        <h3 className="text-xl font-bold text-white font-display tracking-tight">Shopping Cart Empty</h3>
        <p className="text-slate-400 text-xs max-w-sm mx-auto mt-2 mb-6 leading-relaxed">
          You have no checked items inside your Postgres database synchronizer. Click below to browse active merchandise listings.
        </p>
        <Link
          to="/"
          className="px-5 py-3 bg-indigo-600 hover:bg-indigo-550 hover:shadow-[0_0_15px_rgba(79,70,229,0.35)] text-white rounded-xl text-xs font-bold transition-all"
        >
          Explore Merchandises
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 py-10 relative z-10">
      <h1 className="text-2xl font-bold tracking-tight text-white font-display mb-8 flex items-center gap-2">
        <ShoppingBag className="text-indigo-400" size={24} />
        Database Shopping Cart
      </h1>

      {paymentResult ? (
        /* Checkout Success Modal Layout */
        <div className="max-w-2xl mx-auto glass-panel rounded-3xl overflow-hidden shadow-[0_0_50px_rgba(79,70,229,0.15)] p-8 space-y-6 text-center border border-white/10">
          <div className="inline-flex items-center justify-center p-4 bg-indigo-500/10 text-indigo-400 border border-indigo-505/20 rounded-full mb-1">
            <ShieldCheck size={36} />
          </div>
          <div className="space-y-2">
            <h2 className="text-2xl font-bold text-white font-display tracking-tight">Database Transaction Formed!</h2>
            <p className="text-sm text-slate-350">
              Prisma has saved your order records under Code:{" "}
              <span className="font-mono font-bold text-indigo-300">{paymentResult.orderCode}</span>
            </p>
          </div>

          <div className="bg-white/5 rounded-2xl p-6 border border-white/10 text-left space-y-4">
            <h4 className="font-bold text-xs text-indigo-300 uppercase tracking-wider font-mono">Payment Routing Instructions</h4>
            <p className="text-xs text-slate-400 leading-relaxed font-sans">
              We have generated a secure checkout linkage via Midtrans Payments. Please click the action link below to complete the transactions in your terminal safely.
            </p>
            {paymentResult.paymentUrl && (
              <a
                href={paymentResult.paymentUrl}
                target="_blank"
                referrerPolicy="no-referrer"
                rel="noopener noreferrer"
                className="w-full flex items-center justify-center gap-2 py-3 px-4 bg-indigo-650 hover:bg-indigo-600 hover:shadow-[0_0_15px_rgba(79,70,229,0.3)] text-white font-bold text-xs rounded-xl transition-all cursor-pointer border border-indigo-500/20"
              >
                <CreditCard size={14} />
                Open Midtrans Payment Window (External Tab)
              </a>
            )}
          </div>

          <div className="flex justify-center gap-4 pt-4 border-t border-white/10">
            <button
              onClick={() => setPaymentResult(null)}
              className="px-4 py-2 bg-white/5 hover:bg-white/10 text-slate-300 border border-white/10 text-xs font-bold rounded-lg transition-colors cursor-pointer"
            >
              Start New Cart
            </button>
            <Link
              to="/my-orders"
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-550 text-white text-xs font-bold rounded-lg transition-colors inline-flex items-center gap-1"
            >
              <span>View Order History</span>
              <ArrowRight size={12} />
            </Link>
          </div>
        </div>
      ) : (
        /* Actual cart form template */
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart products lists */}
          <div className="lg:col-span-2 space-y-4">
            <div className="flex justify-between items-center pb-4 border-b border-white/10">
              <span className="text-xs font-mono text-slate-400 font-bold uppercase">{cart.length} distinct listings</span>
              <button
                onClick={clearCart}
                className="text-xs text-rose-400 hover:text-rose-300 font-bold font-mono flex items-center gap-1 cursor-pointer transition-all"
              >
                <Trash2 size={12} />
                EMPTY CART
              </button>
            </div>

            <div className="divide-y divide-white/10">
              {cart.map((item) => (
                <div key={item.id} className="py-5 flex gap-4 sm:gap-6 items-center">
                  <div className="w-16 h-16 sm:w-20 sm:h-20 bg-white/5 border border-white/10 rounded-xl overflow-hidden shrink-0 flex items-center justify-center">
                    {item.product?.image ? (
                      <img
                        src={item.product.image}
                        alt={item.product?.name}
                        className="w-full h-full object-cover"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-slate-500">
                        <ShoppingBag size={20} className="text-indigo-400" />
                      </div>
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <h4 className="font-display font-semibold text-white text-sm sm:text-base truncate">
                      {item.product?.name || "Unregistered merchandise ID"}
                    </h4>
                    <span className="inline-block mt-0.5 px-2 py-0.5 rounded text-[9px] font-mono bg-white/10 border border-white/5 text-indigo-300 font-bold uppercase">
                      {item.product?.category || "General"}
                    </span>
                    <p className="text-sm font-bold text-white mt-2 font-mono">
                      {formatIDR(item.product?.price || 0)}
                    </p>
                  </div>

                  <div className="flex flex-col items-end gap-3 shrink-0">
                    <div className="flex items-center border border-white/15 rounded-lg overflow-hidden bg-white/5 text-xs">
                      <button
                        onClick={() => updateCartQty(item.id, item.quantity - 1)}
                        className="p-1 px-2 hover:bg-white/10 transition-colors text-slate-400"
                        title="Decrease"
                      >
                        <Minus size={12} />
                      </button>
                      <span className="px-2 text-white font-bold font-mono w-6 text-center select-none">
                        {item.quantity}
                      </span>
                      <button
                        onClick={() => {
                          if (item.product && item.quantity >= item.product.stock) {
                            showToaster("Cannot buy more than available in inventory", "info");
                          } else {
                            updateCartQty(item.id, item.quantity + 1);
                          }
                        }}
                        className="p-1 px-2 hover:bg-white/10 transition-colors text-slate-400"
                        title="Increase"
                      >
                        <Plus size={12} />
                      </button>
                    </div>

                    <button
                      onClick={() => removeCartItem(item.id)}
                      className="text-slate-500 hover:text-rose-400 p-1 rounded-lg hover:bg-white/5 transition-colors cursor-pointer"
                      title="Clear item specifications"
                    >
                      <Trash2 size={14} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Checkout Summary Right Section */}
          <div className="lg:col-span-1">
            <div className="glass-panel text-slate-100 rounded-3xl p-6 border border-white/10 shadow-[0_0_30px_rgba(79,70,229,0.1)] space-y-6">
              <h3 className="text-sm font-bold uppercase tracking-widest text-slate-400 font-mono pb-3 border-b border-white/10">
                Transaction Overview
              </h3>

              <div className="space-y-3 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-400 font-sans">Database rows total</span>
                  <span className="font-mono text-slate-200">{cart.length} matches</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400 font-sans">Total units count</span>
                  <span className="font-mono text-slate-200">
                    {cart.reduce((tot, item) => tot + item.quantity, 0)} pieces
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400 font-sans">Core Service Charges</span>
                  <span className="text-indigo-400 uppercase font-bold font-mono text-[10px]">FREE / SECURE</span>
                </div>
              </div>

              <div className="pt-4 border-t border-white/10 flex justify-between items-baseline">
                <span className="text-sm font-semibold text-slate-350 font-display">Amount Due</span>
                <span className="text-2xl font-bold font-sans tracking-tight text-white">
                  {formatIDR(totalAmount)}
                </span>
              </div>

              <button
                disabled={loadingCheckout}
                onClick={handleCheckout}
                className="w-full flex items-center justify-center gap-2 py-3.5 bg-indigo-650 hover:bg-indigo-600 text-white font-bold text-sm rounded-xl transition-all cursor-pointer disabled:opacity-50 cursor-pointer disabled:cursor-not-allowed shadow-[0_0_20px_rgba(79,70,229,0.3)] hover:shadow-[0_0_25px_rgba(79,70,229,0.4)]"
              >
                {loadingCheckout ? (
                  <span className="inline-block h-4 w-4 animate-spin rounded-full border-2 border-solid border-white border-r-transparent"></span>
                ) : (
                  <>
                    <CreditCard size={16} />
                    Checkout Postgres Order
                  </>
                )}
              </button>

              <div className="flex items-center gap-2 justify-center text-[10px] text-slate-500 font-mono">
                <Trash2 size={12} className="text-indigo-400 shrink-0" />
                <span>Prisma Client transaction layers active</span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
