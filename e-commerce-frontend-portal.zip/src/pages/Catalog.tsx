import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import api from "../api/axios";
import { useApp } from "../context/AppContext";
import { Product } from "../types";
import { Search, Filter, ShoppingBag, Eye, Star, Info, Inbox } from "lucide-react";

export default function Catalog() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [priceRange, setPriceRange] = useState<number>(50000000); // 50m max Rp
  const { addToCart, showToaster, backendConnected } = useApp();

  const loadProducts = async () => {
    setLoading(true);
    try {
      const res = await api.get("/products");
      if (Array.isArray(res.data)) {
        setProducts(res.data);
      } else {
        setProducts([]);
      }
    } catch (err) {
      console.error("Failed to query Express API endpoints:", err);
      showToaster("Error retrieving dynamic inventory database.", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadProducts();
  }, []);

  const categories = ["all", ...new Set(products.map((p) => p.category || "General"))];

  const filteredProducts = products.filter((p) => {
    const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase()) || 
                          p.description.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = selectedCategory === "all" || (p.category || "General") === selectedCategory;
    const matchesPrice = (p.price || 0) <= priceRange;
    return matchesSearch && matchesCategory && matchesPrice;
  });

  const formatIDR = (num: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      maximumFractionDigits: 0,
    }).format(num);
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 relative z-10 text-slate-100">
      {/* Banner / Hero panel */}
      <div className="glass-panel rounded-3xl p-8 sm:p-12 mb-10 shadow-[0_0_50px_rgba(79,70,229,0.15)] relative overflow-hidden border border-white/10">
        <div className="absolute -right-20 -bottom-20 w-96 h-96 bg-indigo-600 rounded-full blur-[130px] opacity-35 pointer-events-none"></div>
        <div className="absolute -left-10 -top-10 w-48 h-48 bg-purple-650 rounded-full blur-[90px] opacity-20 pointer-events-none"></div>
        <div className="max-w-2xl relative z-10">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 mb-4 animate-pulse">
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-400"></span>
            Cloud Backed E-Commerce Client
          </span>
          <h1 className="text-3xl sm:text-4xl font-display font-bold tracking-tight mb-4 text-white leading-tight">
            Polished Shopping, Connected Directly to Postgres Neon.
          </h1>
          <p className="text-slate-400 text-sm sm:text-base leading-relaxed mb-6">
            A premium interface consuming active custom Express routes. Every purchase, cart action, and transaction is synced straight to your persistent database.
          </p>
          <div className="flex flex-wrap gap-3 text-xs font-mono text-indigo-300">
            <div className="bg-white/5 px-3 py-1.5 rounded-xl border border-white/10 backdrop-blur-md">
              ⚡ Midtrans Sandboxed Payments ready
            </div>
            <div className="bg-white/5 px-3 py-1.5 rounded-xl border border-white/10 backdrop-blur-md">
              🛡️ Role-Based Route Protection active
            </div>
          </div>
        </div>
      </div>

      {/* Backend connection warning */}
      {backendConnected === false && (
        <div className="mb-8 p-4 bg-amber-500/15 border border-amber-500/30 rounded-2xl text-amber-200 flex items-start gap-3 backdrop-blur-md">
          <Info className="text-amber-400 shrink-0 mt-0.5" size={18} />
          <div>
            <h4 className="text-sm font-semibold font-display">Local Server Connection Status: Inactive</h4>
            <p className="text-xs text-slate-300 mt-1 leading-relaxed">
              We could not establish a connection to your backend at <code className="bg-white/10 px-1 py-0.5 rounded font-mono text-[11px] text-amber-300">http://localhost:5000/api</code>. 
              Please verify that your Express API server is active and executing. You can change this address in the Settings menu in the top navigation bar.
            </p>
          </div>
        </div>
      )}

      {/* Filter and catalog layout */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Left Side: Filter controls */}
        <div className="lg:col-span-1 glass-panel p-6 rounded-3xl space-y-6 h-fit border border-white/10">
          <div className="flex items-center justify-between pb-4 border-b border-white/10">
            <h3 className="font-display font-bold text-white flex items-center gap-2 text-sm uppercase tracking-wide">
              <Filter size={16} className="text-indigo-400" />
              Filter Inventory
            </h3>
            <button 
              onClick={() => { setSearch(""); setSelectedCategory("all"); setPriceRange(50000000); }}
              className="text-xs text-indigo-400 hover:text-indigo-300 font-bold font-mono cursor-pointer transition-colors"
            >
              RESET
            </button>
          </div>

          {/* Search text input */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest font-mono">Search</label>
            <div className="relative">
              <Search className="absolute left-3 top-3 text-slate-500" size={16} />
              <input
                type="text"
                placeholder="Title, description..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-2 bg-white/5 border border-white/10 rounded-xl text-sm text-white placeholder-slate-500 focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500 transition-all font-sans"
              />
            </div>
          </div>

          {/* Category Pills */}
          <div className="space-y-2">
            <label className="block text-xs font-bold text-slate-400 uppercase tracking-widest font-mono">Category</label>
            <div className="flex flex-col gap-1.5 max-h-48 overflow-y-auto pr-1">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => setSelectedCategory(cat)}
                  className={`w-full text-left px-3 py-2 rounded-xl text-xs transition-all duration-200 text-capitalize cursor-pointer font-sans ${
                    selectedCategory === cat
                      ? "bg-indigo-600 text-white font-bold border border-indigo-505/30 shadow-[0_0_15px_rgba(79,70,229,0.25)]"
                      : "text-slate-400 hover:text-white hover:bg-white/5"
                  }`}
                >
                  {cat === "all" ? "All Categories" : cat}
                </button>
              ))}
            </div>
          </div>

          {/* Price Range Slider */}
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <label className="text-xs font-bold text-slate-400 uppercase tracking-widest font-mono">Max Price</label>
              <span className="text-xs font-bold text-indigo-400 font-mono">{formatIDR(priceRange)}</span>
            </div>
            <input
              type="range"
              min="1000"
              max="50000000"
              step="50000"
              value={priceRange}
              onChange={(e) => setPriceRange(Number(e.target.value))}
              className="w-full h-1 bg-white/10 rounded-lg appearance-none cursor-pointer accent-indigo-500 focus:outline-none focus:ring-1 focus:ring-indigo-505"
            />
            <div className="flex justify-between text-[10px] font-mono text-slate-500">
              <span>Rp 1.000</span>
              <span>Rp 50M</span>
            </div>
          </div>
        </div>

        {/* Right Side: Grid of inventory */}
        <div className="lg:col-span-3">
          {loading ? (
            <div className="flex flex-col items-center justify-center py-24 glass-panel rounded-3xl border border-white/10">
              <div className="animate-spin rounded-full h-10 w-10 border-2 border-indigo-500 border-t-transparent shadow-[0_0_20px_rgba(99,102,241,0.2)]"></div>
              <p className="text-slate-400 text-xs mt-4 font-mono font-medium">Verifying dynamic system inventory catalogues...</p>
            </div>
          ) : filteredProducts.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-24 text-center glass-panel rounded-3xl px-6 border border-white/10">
              <div className="p-4 bg-white/5 border border-white/10 rounded-full mb-4 text-slate-400 shadow-inner">
                <Inbox size={32} className="text-indigo-400" />
              </div>
              <h3 className="text-lg font-bold font-display text-white">No Products Registered</h3>
              <p className="text-slate-400 text-xs max-w-sm mt-1 mb-6 leading-relaxed">
                Your PostgreSQL database table has no products listed matching these filter bounds, or contains zero items.
              </p>
              <Link
                to="/login"
                className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-550 text-white font-bold text-xs rounded-xl hover:shadow-[0_0_15px_rgba(79,70,229,0.3)] transition-all"
              >
                Access Admin Portal to Setup Inventory
              </Link>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6">
              {filteredProducts.map((p) => (
                <div
                  key={p.id}
                  className="glass-panel rounded-3xl overflow-hidden group hover:border-indigo-500/50 hover:shadow-[0_0_25px_rgba(99,102,241,0.15)] transition-all duration-300 flex flex-col h-full border border-white/10"
                >
                  {/* Image wrapper */}
                  <div className="aspect-[4/3] bg-white/5 relative overflow-hidden shrink-0 border-b border-white/5">
                    {p.image ? (
                      <img
                        src={p.image}
                        alt={p.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-550"
                        referrerPolicy="no-referrer"
                      />
                    ) : (
                      <div className="w-full h-full flex flex-col items-center justify-center text-slate-500 text-xs font-mono">
                        <ShoppingBag size={24} className="mb-2 opacity-50 text-indigo-400" />
                        No product resource uploaded
                      </div>
                    )}
                    <span className="absolute top-3 left-3 bg-slate-950/80 text-indigo-300 border border-white/10 text-[9px] font-mono font-bold tracking-wider uppercase px-2 py-0.5 rounded shadow-lg backdrop-blur-md">
                      {p.category || "General"}
                    </span>
                    {p.stock <= 0 && (
                      <div className="absolute inset-0 bg-slate-950/75 flex items-center justify-center backdrop-blur-xs text-rose-400 text-xs font-display font-medium tracking-widest uppercase">
                        SOLD OUT
                      </div>
                    )}
                  </div>

                  {/* Body Info */}
                  <div className="p-5 flex-1 flex flex-col">
                    <div className="flex-1">
                      <h4 className="font-display font-bold text-white text-base line-clamp-1 mb-1 group-hover:text-indigo-300 transition-colors">{p.name}</h4>
                      <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed mb-4 min-h-[2rem]">
                        {p.description || "No supplemental details registered."}
                      </p>
                    </div>

                    <div className="space-y-4">
                      {/* Price / Stock stats */}
                      <div className="flex justify-between items-end">
                        <div>
                          <p className="text-[9px] font-mono text-slate-500 uppercase tracking-widest">Pricing</p>
                          <span className="text-base font-bold text-white font-sans tracking-tight">{formatIDR(p.price)}</span>
                        </div>
                        <div className="text-right">
                          <p className="text-[9px] font-mono text-slate-500 uppercase tracking-widest">Inventory</p>
                          <span className={`text-[11px] font-mono ${p.stock > 5 ? "text-slate-400" : "text-amber-500 font-bold"}`}>
                            {p.stock > 0 ? `${p.stock} units` : "Out of Stock"}
                          </span>
                        </div>
                      </div>

                      {/* Detail / Add buttons */}
                      <div className="grid grid-cols-5 gap-2">
                        <Link
                          to={`/product/${p.id}`}
                          className="col-span-1.5 flex items-center justify-center rounded-xl border border-white/10 text-slate-400 hover:text-white hover:bg-white/10 cursor-pointer transition-all"
                          title="View Details"
                        >
                          <Eye size={16} />
                        </Link>
                        <button
                          disabled={p.stock <= 0}
                          onClick={() => addToCart(p.id)}
                          className="col-span-3.5 flex items-center justify-center gap-1.5 text-xs font-bold rounded-xl bg-indigo-650 hover:bg-indigo-600 disabled:bg-white/5 disabled:text-slate-500 text-white transition-all py-2.5 cursor-pointer disabled:cursor-not-allowed text-ellipsis overflow-hidden whitespace-nowrap shadow-md shadow-indigo-500/10 hover:shadow-indigo-500/25"
                        >
                          <ShoppingBag size={14} className="shrink-0 text-white" />
                          <span>Buy Now</span>
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
