import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import api from "../api/axios";
import { useApp } from "../context/AppContext";
import { Order } from "../types";
import { Receipt, Calendar, CreditCard, ChevronDown, ChevronUp, CheckCircle, Clock, AlertTriangle, RefreshCw, XCircle, ExternalLink } from "lucide-react";

export default function MyOrders() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [expandedOrders, setExpandedOrders] = useState<Record<string | number, boolean>>({});
  const [checkingStatus, setCheckingStatus] = useState<Record<string, boolean>>({});
  const [cancellingCode, setCancellingCode] = useState<Record<string, boolean>>({});
  const { showToaster, token } = useApp();

  const loadOrders = async () => {
    setLoading(true);
    try {
      const res = await api.get("/checkout/my-orders");
      // Res could be arrays
      if (Array.isArray(res.data)) {
        setOrders(res.data);
      } else {
        setOrders([]);
      }
    } catch (err) {
      console.error(err);
      showToaster("Error importing order tracking list.", "error");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (token) {
      loadOrders();
    }
  }, [token]);

  const toggleExpand = async (order: Order) => {
    const oId = order.id;
    const isNowExpanded = !expandedOrders[oId];
    setExpandedOrders((prev) => ({ ...prev, [oId]: isNowExpanded }));

    // If expanding, we can load rich subcomponents from GET /checkout/my-orders/:id to fully fetch relation items!
    if (isNowExpanded && !order.items) {
      try {
        const res = await api.get(`/checkout/my-orders/${oId}`);
        // Update order list with full related detail items
        setOrders((prevOrders) =>
          prevOrders.map((o) => (o.id === oId ? { ...o, ...res.data } : o))
        );
      } catch (err) {
        console.error("Failed to fetch order inline relational items:", err);
      }
    }
  };

  const handleCheckStatus = async (orderCode: string, orderId: string | number) => {
    setCheckingStatus((prev) => ({ ...prev, [orderCode]: true }));
    try {
      const res = await api.get(`/payment/status/${orderCode}`);
      // Notify status from server
      const updatedStatus = res.data?.status || "PENDING";
      showToaster(`Server synchronizer reports transaction status is: ${updatedStatus}`, "info");
      
      // Update local status representation
      setOrders((prev) =>
        prev.map((o) => (o.orderCode === orderCode ? { ...o, status: updatedStatus } : o))
      );
    } catch (err: any) {
      showToaster(err.response?.data?.message || "Error calling remote payment status API", "error");
    } finally {
      setCheckingStatus((prev) => ({ ...prev, [orderCode]: false }));
    }
  };

  const handleCancelPayment = async (orderCode: string) => {
    if (!window.confirm(`Are you certain you wish to cancel Checkout Statement: ${orderCode}?`)) return;
    setCancellingCode((prev) => ({ ...prev, [orderCode]: true }));
    try {
      await api.post(`/payment/cancel/${orderCode}`);
      showToaster(`Transaction Code ${orderCode} cancelled successfully!`, "success");
      
      // Update status to CANCELLED locally
      setOrders((prev) =>
        prev.map((o) => (o.orderCode === orderCode ? { ...o, status: "CANCELLED" } : o))
      );
    } catch (err: any) {
      showToaster(err.response?.data?.message || "Failed to issue cancel command to payment gateways", "error");
    } finally {
      setCancellingCode((prev) => ({ ...prev, [orderCode]: false }));
    }
  };

  const formatIDR = (num: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      maximumFractionDigits: 0,
    }).format(num);
  };

  const getStatusBadge = (status: string) => {
    const s = status?.toUpperCase();
    switch (s) {
      case "PAID":
      case "COMPLETED":
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
            <CheckCircle size={12} />
            {s}
          </span>
        );
      case "PENDING":
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-500/10 text-amber-300 border border-amber-500/20 animate-pulse">
            <Clock size={12} />
            PENDING
          </span>
        );
      case "SHIPPED":
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-indigo-500/10 text-indigo-300 border border-indigo-500/20">
            <RefreshCw size={12} className="animate-spin" />
            SHIPPED
          </span>
        );
      case "CANCELLED":
      case "EXPIRED":
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-white/5 text-slate-400 border border-white/10">
            <XCircle size={12} />
            {s}
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-white/5 text-slate-350 border border-white/10">
            <AlertTriangle size={12} />
            {status || "UNKNOWN"}
          </span>
        );
    }
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 flex flex-col items-center justify-center min-h-[50vh] relative z-10">
        <div className="animate-spin rounded-full h-10 w-10 border-2 border-indigo-500 border-t-transparent shadow-[0_0_20px_rgba(99,102,241,0.2)]"></div>
        <p className="text-slate-400 text-xs mt-4 font-mono">Importing personal transaction invoices...</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 py-10 relative z-10">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-2xl font-bold tracking-tight text-white font-display flex items-center gap-2">
            <Receipt className="text-indigo-400" size={24} />
            My Order Invoices
          </h1>
          <p className="text-xs text-slate-400 mt-1">Check status, access remote checkout logs, or trigger cancellations instantly.</p>
        </div>
        <button
          onClick={loadOrders}
          className="p-2 border border-white/10 hover:bg-white/10 rounded-lg text-slate-300 shadow-sm cursor-pointer transition-colors bg-white/5"
          title="Reload order databases"
        >
          <RefreshCw size={16} />
        </button>
      </div>

      {orders.length === 0 ? (
        <div className="glass-panel rounded-3xl py-16 text-center px-4 border border-white/10 shadow-[0_0_30px_rgba(79,70,229,0.15)]">
          <div className="p-4 bg-white/5 border border-white/10 inline-block rounded-full mb-3 text-slate-400">
            <Receipt size={36} className="text-indigo-400" />
          </div>
          <h3 className="text-lg font-bold text-white font-display">No Orders Incurred</h3>
          <p className="text-slate-400 text-xs max-w-sm mx-auto mt-1 mb-6">
            There are no transactional checkout operations recorded inside database tables under your registered profile.
          </p>
          <Link
            to="/"
            className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-550 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-indigo-500/20"
          >
            Start Shopping Now
          </Link>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map((order) => {
            const isExpanded = expandedOrders[order.id];
            return (
              <div
                key={order.id}
                className="glass-panel rounded-3xl overflow-hidden hover:border-indigo-500/50 hover:shadow-[0_0_20px_rgba(99,102,241,0.1)] transition-all duration-300 text-white border border-white/10"
              >
                {/* Header overview card row */}
                <div
                  onClick={() => toggleExpand(order)}
                  className="p-5 sm:p-6 flex flex-wrap gap-4 items-center justify-between cursor-pointer select-none bg-white/5 hover:bg-white/10 transition-colors duration-200"
                >
                  <div className="space-y-1 min-w-[200px]">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span className="font-mono text-sm font-bold text-white">
                        {order.orderCode}
                      </span>
                      {getStatusBadge(order.status)}
                    </div>
                    <div className="flex items-center gap-3 text-xs text-slate-400 font-mono">
                      <span className="flex items-center gap-1">
                        <Calendar size={12} className="text-indigo-400" />
                        {new Date(order.createdAt).toLocaleDateString()}
                      </span>
                    </div>
                  </div>

                  <div className="flex items-center gap-6">
                    <div className="text-right">
                      <p className="text-[9px] uppercase font-mono tracking-widest text-slate-500 font-bold">Total Charged</p>
                      <p className="text-base font-bold font-sans tracking-tight text-white">
                        {formatIDR(order.totalAmount)}
                      </p>
                    </div>
                    <div className="text-slate-400">{isExpanded ? <ChevronUp size={18} /> : <ChevronDown size={18} />}</div>
                  </div>
                </div>

                {/* Expanded details container */}
                {isExpanded && (
                  <div className="p-5 sm:p-6 border-t border-white/10 bg-white/5 space-y-6 animate-fade-in text-slate-200">
                    {/* Collapsible item sublist */}
                    <div className="space-y-3.5">
                      <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-300 font-mono">
                        Purchased Items Table
                      </h4>
                      {!order.items ? (
                        <div className="py-4 text-center text-xs text-slate-500 font-mono">
                          Importing invoice relation sheets...
                        </div>
                      ) : (
                        <div className="divide-y divide-white/10">
                          {order.items.map((sub) => (
                            <div key={sub.id} className="py-3 flex items-center justify-between gap-4">
                              <div className="flex items-center gap-3 min-w-0">
                                <div className="w-10 h-10 bg-white/10 rounded-lg overflow-hidden shrink-0 border border-white/10 flex items-center justify-center">
                                  {sub.product?.image ? (
                                    <img
                                      src={sub.product.image}
                                      alt="Product icon"
                                      className="w-full h-full object-cover"
                                      referrerPolicy="no-referrer"
                                    />
                                  ) : (
                                    <div className="w-full h-full flex items-center justify-center text-slate-500 bg-white/5">
                                      <Receipt size={14} className="text-indigo-400" />
                                    </div>
                                  )}
                                </div>
                                <div className="min-w-0">
                                  <p className="text-xs font-bold font-display text-white truncate">
                                    {sub.product?.name || "Unlisted catalog key"}
                                  </p>
                                  <p className="text-[10px] text-slate-400 font-mono">
                                    {sub.quantity} unit{sub.quantity > 1 ? "s" : ""} × {formatIDR(sub.price)}
                                  </p>
                                </div>
                              </div>
                              <span className="text-xs font-bold text-white font-mono shrink-0">
                                {formatIDR(sub.price * sub.quantity)}
                              </span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Operational system actions */}
                    <div className="pt-5 border-t border-white/10 flex flex-wrap gap-4 items-center justify-between text-xs">
                      <div className="flex gap-2">
                        {/* Verify button */}
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleCheckStatus(order.orderCode, order.id);
                          }}
                          disabled={checkingStatus[order.orderCode]}
                          className="px-4 py-2 bg-indigo-650 hover:bg-indigo-600 text-white font-bold rounded-lg flex items-center gap-1.5 cursor-pointer transition-all disabled:opacity-50 hover:shadow-[0_0_15px_rgba(79,70,229,0.3)]"
                        >
                          <RefreshCw size={12} className={checkingStatus[order.orderCode] ? "animate-spin" : ""} />
                          Check Payment Status
                        </button>

                        {/* Midtrans payment launch when pending */}
                        {order.status === "PENDING" && order.paymentUrl && (
                          <a
                            href={order.paymentUrl}
                            target="_blank"
                            rel="noopener noreferrer"
                            className="bg-emerald-650 hover:bg-emerald-600 text-white font-bold px-4 py-2 rounded-lg flex items-center gap-1.5 transition-all shadow-[0_0_15px_rgba(16,185,129,0.3)]"
                          >
                            <ExternalLink size={12} />
                            Launch Midtrans
                          </a>
                        )}
                      </div>

                      {/* Cancel payments action when pending */}
                      {order.status?.toUpperCase() === "PENDING" && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleCancelPayment(order.orderCode);
                          }}
                          disabled={cancellingCode[order.orderCode]}
                          className="px-4 py-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-300 border border-rose-500/20 font-bold rounded-lg flex items-center gap-1 text-xs cursor-pointer transition-colors disabled:opacity-50"
                        >
                          <XCircle size={12} />
                          Cancel Open Statement
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
